"This package collects XML schemata."
